filechoicebk3 = global.filechoice;
keepgold = global.gold;
keepmaxhp = global.maxhp;
global.filechoice = 9;
script_execute(scr_load);
global.filechoice = filechoicebk3;
global.gold = keepgold;
global.maxhp = keepmaxhp;
global.hp = global.maxhp;
