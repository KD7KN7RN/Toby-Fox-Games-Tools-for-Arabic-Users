@echo off
cd /d "%~dp0"

set "SCRIPT_NAME=%~nx0"

echo Renaming files and folders to lowercase...
echo Please wait...

powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path . -Recurse | Sort-Object -Property {$_.FullName.Length} -Descending | ForEach-Object { $newName = $_.Name.ToLower(); if ($_.Name -cne $newName -and $_.Name -ne $env:SCRIPT_NAME) { $temp = $_.Name + '_temp' + (Get-Random); $tempItem = Rename-Item -LiteralPath $_.FullName -NewName $temp -PassThru; Rename-Item -LiteralPath $tempItem.FullName -NewName $newName -Force } }"

echo.
echo Done!
pause