using System.Text;
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

EnsureDataLoaded();

ScriptMessage("For older devices that cannot handle Deltarune's shaders.");

List<string> shadersNonExist = new List<string>();
for (var i = 0; i < Data.Shaders.Count; i++)
    shadersNonExist.Add(Data.Shaders[i].Name.Content);
Data.Shaders.Clear();
foreach (string str in shadersNonExist)
{
    UndertaleShader existing_shader = new UndertaleShader();
    existing_shader.Name = Data.Strings.MakeString(str);
    existing_shader.GLSL_ES_Fragment = Data.Strings.MakeString("");
    existing_shader.GLSL_ES_Vertex = Data.Strings.MakeString("");
    existing_shader.GLSL_Fragment = Data.Strings.MakeString("");
    existing_shader.GLSL_Vertex = Data.Strings.MakeString("");
    existing_shader.HLSL9_Fragment = Data.Strings.MakeString("");
    existing_shader.HLSL9_Vertex = Data.Strings.MakeString("");
    Data.Shaders.Add(existing_shader);
}
