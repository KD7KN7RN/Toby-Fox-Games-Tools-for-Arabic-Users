image_alpha = (con >= 0) ? min(image_alpha + 0.1, touchscreen_opacity) : max(image_alpha - 0.1, 0);
var _f_enable = (instance_exists(obj_spamton_neo_enemy) && !obj_spamton_neo_enemy.party_heal) || (instance_exists(obj_spamton_enemy) && obj_spamton_enemy.help_counter > 0 && !obj_spamton_enemy.party_heal);
f_alpha = (_f_enable || con == 99) ? min(f_alpha + 0.1, 1) : max(f_alpha - 0.1, 0);
settings_alpha = (con == 99) ? min(settings_alpha + 0.1, 1) : max(settings_alpha - 0.1, 0);
settings_z = 0;
var _key_state = array_create(array_length_1d(keybind), 0);
var _joystick_fade = [0];

switch (con)
{
    case -1:
        var _x = device_mouse_x_to_gui(0);
        var _y = device_mouse_y_to_gui(0);
        var _held = device_mouse_check_button(0, mb_any);
        var _x0 = settings_x - (sprite_get_xoffset(spr_mobilecontrols_s) * touchscreen_scale[1]);
        var _y0 = settings_y - (sprite_get_yoffset(spr_mobilecontrols_s) * touchscreen_scale[1]);
        var _x1 = _x0 + (sprite_get_width(spr_mobilecontrols_s) * touchscreen_scale[1]);
        var _y1 = _y0 + (sprite_get_height(spr_mobilecontrols_s) * touchscreen_scale[1]);
        
        if (ds_list_find_value(held, 4) < 0 && ds_list_find_index(held, 0) < 0 && _held == 1 && _x > _x0 && _x < _x1 && _y > _y0 && _y < _y1)
            ds_list_set(held, 4, 0);
        
        if (ds_list_find_value(held, 4) == 0)
        {
            if (_held == 1)
            {
                settings_z = 1;
            }
            else
            {
                event_user(0);
                con = 0;
            }
        }
        
        break;
    
    case 0:
        for (var j = 0; j < 5; j++)
        {
            var _x = device_mouse_x_to_gui(j);
            var _y = device_mouse_y_to_gui(j);
            var _held = device_mouse_check_button(j, mb_any);
            
            for (var i = 0; i <= 5; i++)
            {
                switch (i)
                {
                    case 0:
                        var _x0 = touchscreen_x[0] - (sprite_get_xoffset(spr_mobilecontrols_z) * touchscreen_scale[1]);
                        var _y0 = touchscreen_y[0] - (sprite_get_yoffset(spr_mobilecontrols_z) * touchscreen_scale[1]);
                        var _x1 = _x0 + (sprite_get_width(spr_mobilecontrols_z) * touchscreen_scale[1]);
                        var _y1 = _y0 + (sprite_get_height(spr_mobilecontrols_z) * touchscreen_scale[1]);
                        
                        if (ds_list_find_value(held, i) < 0 && ds_list_find_index(held, j) < 0 && _held == 1 && _x > _x0 && _x < _x1 && _y > _y0 && _y < _y1)
                            ds_list_set(held, i, j);
                        
                        if (ds_list_find_value(held, i) == j)
                        {
                            if (_held == 1)
                            {
                                if (_x > _x0 && _x < _x1 && _y > _y0 && _y < _y1)
                                    _key_state[4] = 1;
                                else
                                    _key_state[4] = 0;
                            }
                            else
                            {
                                _key_state[4] = 0;
                                ds_list_set(held, i, -1);
                            }
                        }
                        
                        break;
                    
                    case 1:
                        var _x0 = touchscreen_x[1] - (sprite_get_xoffset(spr_mobilecontrols_x) * touchscreen_scale[1]);
                        var _y0 = touchscreen_y[1] - (sprite_get_yoffset(spr_mobilecontrols_x) * touchscreen_scale[1]);
                        var _x1 = _x0 + (sprite_get_width(spr_mobilecontrols_x) * touchscreen_scale[1]);
                        var _y1 = _y0 + (sprite_get_height(spr_mobilecontrols_x) * touchscreen_scale[1]);
                        
                        if (ds_list_find_value(held, i) < 0 && ds_list_find_index(held, j) < 0 && _held == 1 && _x > _x0 && _x < _x1 && _y > _y0 && _y < _y1)
                            ds_list_set(held, i, j);
                        
                        if (ds_list_find_value(held, i) == j)
                        {
                            if (_held == 1)
                            {
                                if (_x > _x0 && _x < _x1 && _y > _y0 && _y < _y1)
                                    _key_state[5] = 1;
                                else
                                    _key_state[5] = 0;
                            }
                            else
                            {
                                _key_state[5] = 0;
                                ds_list_set(held, i, -1);
                            }
                        }
                        
                        break;
                    
                    case 2:
                        var _x0 = touchscreen_x[2] - (sprite_get_xoffset(spr_mobilecontrols_c) * touchscreen_scale[1]);
                        var _y0 = touchscreen_y[2] - (sprite_get_yoffset(spr_mobilecontrols_c) * touchscreen_scale[1]);
                        var _x1 = _x0 + (sprite_get_width(spr_mobilecontrols_c) * touchscreen_scale[1]);
                        var _y1 = _y0 + (sprite_get_height(spr_mobilecontrols_c) * touchscreen_scale[1]);
                        
                        if (ds_list_find_value(held, i) < 0 && ds_list_find_index(held, j) < 0 && _held == 1 && _x > _x0 && _x < _x1 && _y > _y0 && _y < _y1)
                            ds_list_set(held, i, j);
                        
                        if (ds_list_find_value(held, i) == j)
                        {
                            if (_held == 1)
                            {
                                if (_x > _x0 && _x < _x1 && _y > _y0 && _y < _y1)
                                    _key_state[6] = 1;
                                else
                                    _key_state[6] = 0;
                            }
                            else
                            {
                                _key_state[6] = 0;
                                ds_list_set(held, i, -1);
                            }
                        }
                        
                        break;
                    
                    case 3:
                        var _x0 = touchscreen_x[3] - (sprite_get_xoffset(spr_mobilecontrols_f) * touchscreen_scale[1]);
                        var _y0 = touchscreen_y[3] - (sprite_get_yoffset(spr_mobilecontrols_f) * touchscreen_scale[1]);
                        var _x1 = _x0 + (sprite_get_width(spr_mobilecontrols_f) * touchscreen_scale[1]);
                        var _y1 = _y0 + (sprite_get_height(spr_mobilecontrols_f) * touchscreen_scale[1]);
                        
                        if (ds_list_find_value(held, i) < 0 && ds_list_find_index(held, j) < 0 && _held == 1 && _x > _x0 && _x < _x1 && _y > _y0 && _y < _y1)
                            ds_list_set(held, i, j);
                        
                        if (ds_list_find_value(held, i) == j)
                        {
                            if (_held == 1)
                            {
                                if (_x > _x0 && _x < _x1 && _y > _y0 && _y < _y1)
                                    _key_state[7] = 1;
                                else
                                    _key_state[7] = 0;
                            }
                            else
                            {
                                _key_state[7] = 0;
                                ds_list_set(held, i, -1);
                            }
                        }
                        
                        if (_f_enable == 0)
                            _key_state[7] = 0;
                        
                        break;
                    
                    case 4:
                        var _x0 = settings_x - (sprite_get_xoffset(spr_mobilecontrols_s) * touchscreen_scale[1]);
                        var _y0 = settings_y - (sprite_get_yoffset(spr_mobilecontrols_s) * touchscreen_scale[1]);
                        var _x1 = _x0 + (sprite_get_width(spr_mobilecontrols_s) * touchscreen_scale[1]);
                        var _y1 = _y0 + (sprite_get_height(spr_mobilecontrols_s) * touchscreen_scale[1]);
                        
                        if (ds_list_find_value(held, i) < 0 && ds_list_find_index(held, j) < 0 && _held == 1 && _x > _x0 && _x < _x1 && _y > _y0 && _y < _y1)
                            ds_list_set(held, i, j);
                        
                        if (ds_list_find_value(held, i) == j)
                        {
                            if (_held == 1)
                            {
                                settings_z = 1;
                                timer += 1;
                            }
                            else
                            {
                                if (timer > 30)
                                {
                                    event_user(0);
                                    con = 99;
                                }
                                else
                                {
                                    event_user(0);
                                    con = -1;
                                }
                                
                                timer = 0;
                            }
                        }
                        
                        break;
                    
                    case 5:
                        switch (touchscreen_type)
                        {
                            case 0:
                            case 1:
                                joybase_x[0] = touchscreen_x[4];
                                joybase_y[0] = touchscreen_y[4];
                                var _x0 = joybase_x[0] - (sprite_get_xoffset(spr_mobilecontrols_jb) * touchscreen_scale[0]);
                                var _y0 = joybase_y[0] - (sprite_get_yoffset(spr_mobilecontrols_jb) * touchscreen_scale[0]);
                                var _x1 = _x0 + (sprite_get_width(spr_mobilecontrols_jb) * touchscreen_scale[0]);
                                var _y1 = _y0 + (sprite_get_height(spr_mobilecontrols_jb) * touchscreen_scale[0]);
                                
                                if (ds_list_find_value(held, i) < 0 && ds_list_find_index(held, j) < 0 && _held == 1 && _x > _x0 && _x < _x1 && _y > _y0 && _y < _y1)
                                    ds_list_set(held, i, j);
                                
                                if (ds_list_find_value(held, i) == j)
                                {
                                    if (_held == 1)
                                    {
                                        var _radius = point_distance(_x0, _y0, _x1, _y1) / 3;
                                        var _distance = point_distance(joybase_x[0], joybase_y[0], _x, _y);
                                        var _angle = point_direction(joybase_x[0], joybase_y[0], _x, _y);
                                        joystick_x[0] = _x;
                                        joystick_y[0] = _y;
                                        
                                        if (_distance > _radius)
                                        {
                                            joystick_x[0] = joybase_x[0] + lengthdir_x(_radius, _angle);
                                            joystick_y[0] = joybase_y[0] + lengthdir_y(_radius, _angle);
                                        }
                                        
                                        var _deadzone = lerp(0.1, 0.9, touchscreen_deadzone) * _radius;
                                        _key_state[0] = 0;
                                        _key_state[1] = 0;
                                        _key_state[2] = 0;
                                        _key_state[3] = 0;
                                        
                                        if (_distance > _deadzone)
                                        {
                                            if (_angle < 67.5 || _angle > 292.5)
                                                _key_state[2] = 1;
                                            
                                            if (_angle > 22.5 && _angle < 157.5)
                                                _key_state[1] = 1;
                                            
                                            if (_angle > 112.5 && _angle < 247.5)
                                                _key_state[0] = 1;
                                            
                                            if (_angle > 202.5 && _angle < 337.5)
                                                _key_state[3] = 1;
                                        }
                                        
                                        _joystick_fade[0] = 1;
                                    }
                                    else
                                    {
                                        _key_state[0] = 0;
                                        _key_state[1] = 0;
                                        _key_state[2] = 0;
                                        _key_state[3] = 0;
                                        ds_list_set(held, i, -1);
                                    }
                                }
                                
                                if (_joystick_fade[0] == 0)
                                {
                                    joystick_x[0] = joybase_x[0];
                                    joystick_y[0] = joybase_y[0];
                                    _joystick_fade[0] = 1;
                                }
                                
                                break;
                            
                            case 2:
                            case 3:
                                if (ds_list_find_value(held, i) < 0 && ds_list_find_index(held, j) < 0 && _held == 1 && _x < 320 && _y > 160)
                                {
                                    joybase_x[0] = _x;
                                    joybase_y[0] = _y;
                                    joystick_x[0] = _x;
                                    joystick_y[0] = _y;
                                    ds_list_set(held, i, j);
                                }
                                
                                var _x0 = joybase_x[0] - (sprite_get_xoffset(spr_mobilecontrols_jb) * touchscreen_scale[0]);
                                var _y0 = joybase_y[0] - (sprite_get_yoffset(spr_mobilecontrols_jb) * touchscreen_scale[0]);
                                var _x1 = _x0 + (sprite_get_width(spr_mobilecontrols_jb) * touchscreen_scale[0]);
                                var _y1 = _y0 + (sprite_get_height(spr_mobilecontrols_jb) * touchscreen_scale[0]);
                                
                                if (ds_list_find_value(held, i) == j)
                                {
                                    if (_held == 1)
                                    {
                                        var _radius = point_distance(_x0, _y0, _x1, _y1) / 3;
                                        var _distance = point_distance(joybase_x[0], joybase_y[0], _x, _y);
                                        var _angle = point_direction(joybase_x[0], joybase_y[0], _x, _y);
                                        joystick_x[0] = _x;
                                        joystick_y[0] = _y;
                                        
                                        if (_distance > _radius)
                                        {
                                            joystick_x[0] = joybase_x[0] + lengthdir_x(_radius, _angle);
                                            joystick_y[0] = joybase_y[0] + lengthdir_y(_radius, _angle);
                                        }
                                        
                                        var _deadzone = lerp(0.1, 0.9, touchscreen_deadzone) * _radius;
                                        _key_state[0] = 0;
                                        _key_state[1] = 0;
                                        _key_state[2] = 0;
                                        _key_state[3] = 0;
                                        
                                        if (_distance > _deadzone)
                                        {
                                            if (_angle < 67.5 || _angle > 292.5)
                                                _key_state[2] = 1;
                                            
                                            if (_angle > 22.5 && _angle < 157.5)
                                                _key_state[1] = 1;
                                            
                                            if (_angle > 112.5 && _angle < 247.5)
                                                _key_state[0] = 1;
                                            
                                            if (_angle > 202.5 && _angle < 337.5)
                                                _key_state[3] = 1;
                                        }
                                        
                                        _joystick_fade[0] = 1;
                                    }
                                    else
                                    {
                                        _key_state[0] = 0;
                                        _key_state[1] = 0;
                                        _key_state[2] = 0;
                                        _key_state[3] = 0;
                                        ds_list_set(held, i, -1);
                                    }
                                }
                                
                                if (_joystick_fade[0] == 0)
                                {
                                    joystick_x[0] = joybase_x[0];
                                    joystick_y[0] = joybase_y[0];
                                }
                                
                                break;
                        }
                        
                        break;
                }
            }
        }
        
        break;
    
    case 99:
        var _x = device_mouse_x_to_gui(0);
        var _y = device_mouse_y_to_gui(0);
        var _held = device_mouse_check_button(0, mb_any);
        
        for (var i = 0; i <= 5; i++)
        {
            switch (i)
            {
                case 0:
                    var _x0 = touchscreen_x[0] - (sprite_get_xoffset(spr_mobilecontrols_z) * touchscreen_scale[1]);
                    var _y0 = touchscreen_y[0] - (sprite_get_yoffset(spr_mobilecontrols_z) * touchscreen_scale[1]);
                    var _x1 = _x0 + (sprite_get_width(spr_mobilecontrols_z) * touchscreen_scale[1]);
                    var _y1 = _y0 + (sprite_get_height(spr_mobilecontrols_z) * touchscreen_scale[1]);
                    
                    if (ds_list_find_value(held, i) < 0 && ds_list_find_index(held, 0) < 0 && _held == 1 && _x > _x0 && _x < _x1 && _y > _y0 && _y < _y1)
                        ds_list_set(held, i, 0);
                    
                    if (ds_list_find_value(held, i) == 0)
                    {
                        if (_held == 1)
                        {
                            touchscreen_x[0] = max(_x, 320);
                            touchscreen_y[0] = _y;
                        }
                        else
                        {
                            ds_list_set(held, i, -1);
                        }
                    }
                    
                    break;
                
                case 1:
                    var _x0 = touchscreen_x[1] - (sprite_get_xoffset(spr_mobilecontrols_x) * touchscreen_scale[1]);
                    var _y0 = touchscreen_y[1] - (sprite_get_yoffset(spr_mobilecontrols_x) * touchscreen_scale[1]);
                    var _x1 = _x0 + (sprite_get_width(spr_mobilecontrols_x) * touchscreen_scale[1]);
                    var _y1 = _y0 + (sprite_get_height(spr_mobilecontrols_x) * touchscreen_scale[1]);
                    
                    if (ds_list_find_value(held, i) < 0 && ds_list_find_index(held, 0) < 0 && _held == 1 && _x > _x0 && _x < _x1 && _y > _y0 && _y < _y1)
                        ds_list_set(held, i, 0);
                    
                    if (ds_list_find_value(held, i) == 0)
                    {
                        if (_held == 1)
                        {
                            touchscreen_x[1] = max(_x, 320);
                            touchscreen_y[1] = _y;
                        }
                        else
                        {
                            ds_list_set(held, i, -1);
                        }
                    }
                    
                    break;
                
                case 2:
                    var _x0 = touchscreen_x[2] - (sprite_get_xoffset(spr_mobilecontrols_c) * touchscreen_scale[1]);
                    var _y0 = touchscreen_y[2] - (sprite_get_yoffset(spr_mobilecontrols_c) * touchscreen_scale[1]);
                    var _x1 = _x0 + (sprite_get_width(spr_mobilecontrols_c) * touchscreen_scale[1]);
                    var _y1 = _y0 + (sprite_get_height(spr_mobilecontrols_c) * touchscreen_scale[1]);
                    
                    if (ds_list_find_value(held, i) < 0 && ds_list_find_index(held, 0) < 0 && _held == 1 && _x > _x0 && _x < _x1 && _y > _y0 && _y < _y1)
                        ds_list_set(held, i, 0);
                    
                    if (ds_list_find_value(held, i) == 0)
                    {
                        if (_held == 1)
                        {
                            touchscreen_x[2] = max(_x, 320);
                            touchscreen_y[2] = _y;
                        }
                        else
                        {
                            ds_list_set(held, i, -1);
                        }
                    }
                    
                    break;
                
                case 3:
                    var _x0 = touchscreen_x[3] - (sprite_get_xoffset(spr_mobilecontrols_f) * touchscreen_scale[1]);
                    var _y0 = touchscreen_y[3] - (sprite_get_yoffset(spr_mobilecontrols_f) * touchscreen_scale[1]);
                    var _x1 = _x0 + (sprite_get_width(spr_mobilecontrols_f) * touchscreen_scale[1]);
                    var _y1 = _y0 + (sprite_get_height(spr_mobilecontrols_f) * touchscreen_scale[1]);
                    
                    if (ds_list_find_value(held, i) < 0 && ds_list_find_index(held, 0) < 0 && _held == 1 && _x > _x0 && _x < _x1 && _y > _y0 && _y < _y1)
                        ds_list_set(held, i, 0);
                    
                    if (ds_list_find_value(held, i) == 0)
                    {
                        if (_held == 1)
                        {
                            touchscreen_x[3] = max(_x, 320);
                            touchscreen_y[3] = _y;
                        }
                        else
                        {
                            ds_list_set(held, i, -1);
                        }
                    }
                    
                    break;
                
                case 4:
                    var _x0 = settings_x - (sprite_get_xoffset(spr_mobilecontrols_s) * touchscreen_scale[1]);
                    var _y0 = settings_y - (sprite_get_yoffset(spr_mobilecontrols_s) * touchscreen_scale[1]);
                    var _x1 = _x0 + (sprite_get_width(spr_mobilecontrols_s) * touchscreen_scale[1]);
                    var _y1 = _y0 + (sprite_get_height(spr_mobilecontrols_s) * touchscreen_scale[1]);
                    
                    if (ds_list_find_value(held, i) < 0 && ds_list_find_index(held, 0) < 0 && _held == 1 && _x > _x0 && _x < _x1 && _y > _y0 && _y < _y1)
                        ds_list_set(held, i, 0);
                    
                    if (ds_list_find_value(held, i) == 0)
                    {
                        if (_held == 1)
                        {
                            settings_z = 1;
                            timer += 1;
                        }
                        else
                        {
                            if (timer > 30)
                            {
                                event_user(0);
                                touchscreen_x = [520, 580, 460, 600, 80];
                                touchscreen_y = [320, 380, 380, 40, 360];
                                touchscreen_deadzone = 0.5;
                                touchscreen_scale = [2.5, 2.5];
                                touchscreen_type = 2;
                                touchscreen_opacity = 0.7;
                            }
                            else
                            {
                                event_user(0);
                                ini_open("touch.ini");
                                ini_write_real("Touchscreen", "Zx", touchscreen_x[0]);
                                ini_write_real("Touchscreen", "Zy", touchscreen_y[0]);
                                ini_write_real("Touchscreen", "Xx", touchscreen_x[1]);
                                ini_write_real("Touchscreen", "Xy", touchscreen_y[1]);
                                ini_write_real("Touchscreen", "Cx", touchscreen_x[2]);
                                ini_write_real("Touchscreen", "Cy", touchscreen_y[2]);
                                ini_write_real("Touchscreen", "Fx", touchscreen_x[3]);
                                ini_write_real("Touchscreen", "Fy", touchscreen_y[3]);
                                ini_write_real("Touchscreen", "Jx", touchscreen_x[4]);
                                ini_write_real("Touchscreen", "Jy", touchscreen_y[4]);
                                ini_write_real("Touchscreen", "JoystickScale", touchscreen_scale[0]);
                                ini_write_real("Touchscreen", "ButtonScale", touchscreen_scale[1]);
                                ini_write_real("Touchscreen", "Deadzone", touchscreen_deadzone);
                                ini_write_real("Touchscreen", "Type", touchscreen_type);
                                ini_write_real("Touchscreen", "Opacity", touchscreen_opacity);
                                ini_close();
                                con = 0;
                            }
                            
                            timer = 0;
                        }
                    }
                    
                    break;
                
                case 5:
                    if (ds_list_find_value(held, i) < 0 && ds_list_find_index(held, 0) < 0 && _held == 1 && _x < 320)
                    {
                        if (_x > 40 && _x < 286 && _y > 117 && _y < 145)
                            settings_slider = 0;
                        
                        if (_x > 40 && _x < 286 && _y > 181 && _y < 209)
                            settings_slider = 1;
                        
                        if (_x > 40 && _x < 286 && _y > 245 && _y < 273)
                            settings_slider = 2;
                        
                        if (_x > 40 && _x < 286 && _y > 309 && _y < 337)
                            settings_slider = 3;
                        
                        if (_x > 40 && _x < 286 && _y > 373 && _y < 401)
                            settings_slider = 4;
                        
                        if (touchscreen_type == 0 || touchscreen_type == 1)
                        {
                            var _x0 = joybase_x[0] - (sprite_get_xoffset(spr_mobilecontrols_jb) * touchscreen_scale[0]);
                            var _y0 = joybase_y[0] - (sprite_get_yoffset(spr_mobilecontrols_jb) * touchscreen_scale[0]);
                            var _x1 = _x0 + (sprite_get_width(spr_mobilecontrols_jb) * touchscreen_scale[0]);
                            var _y1 = _y0 + (sprite_get_height(spr_mobilecontrols_jb) * touchscreen_scale[0]);
                            
                            if (_x > _x0 && _x < _x1 && _y > _y0 && _y < _y1)
                                settings_slider = 5;
                        }
                        
                        ds_list_set(held, i, 0);
                    }
                    
                    if (ds_list_find_value(held, i) == 0)
                    {
                        if (_held == 1)
                        {
                            var _slider = clamp((_x - 54) / 214, 0, 1);
                            
                            switch (settings_slider)
                            {
                                case 0:
                                    touchscreen_deadzone = lerp(0, 1, _slider);
                                    break;
                                
                                case 1:
                                    touchscreen_scale[0] = lerp(2, 4, _slider);
                                    break;
                                
                                case 2:
                                    touchscreen_scale[1] = lerp(2, 4, _slider);
                                    break;
                                
                                case 3:
                                    if (_slider == 0)
                                        touchscreen_type = 0;
                                    
                                    if (_slider > 0.25 && _slider < 0.5)
                                        touchscreen_type = 1;
                                    
                                    if (_slider > 0.5 && _slider < 0.75)
                                        touchscreen_type = 2;
                                    
                                    if (_slider == 1)
                                        touchscreen_type = 3;
                                    
                                    break;
                                
                                case 4:
                                    touchscreen_opacity = lerp(0.2, 1, _slider);
                                    break;
                                
                                case 5:
                                    touchscreen_x[4] = min(_x, 320);
                                    touchscreen_y[4] = max(_y, 160);
                                    break;
                            }
                        }
                        else
                        {
                            settings_slider = -1;
                            ds_list_set(held, i, -1);
                        }
                    }
                    
                    if (touchscreen_type == 0 || touchscreen_type == 1)
                    {
                        joybase_x[0] = touchscreen_x[4];
                        joybase_y[0] = touchscreen_y[4];
                        joystick_x[0] = joybase_x[0];
                        joystick_y[0] = joybase_y[0];
                        _joystick_fade[0] = 1;
                    }
                    
                    break;
            }
        }
        
        break;
}

for (var i = 0; i < array_length_1d(key_state); i++)
{
    if (key_state[i] != _key_state[i])
    {
        if (_key_state[i] == 1)
            keyboard_key_press(keybind[i]);
        else
            keyboard_key_release(keybind[i]);
        
        key_state[i] = _key_state[i];
    }
}

for (var i = 0; i < array_length_1d(joystick_alpha); i++)
    joystick_alpha[i] = _joystick_fade[i] ? min(joystick_alpha[i] + 0.1, 5) : max(joystick_alpha[i] - 0.1, 0);
