function ossafe_game_change(runner)
{
	with (all)
	{
		event_perform(ev_other, ev_game_end);
	}
	
	game_change_ext(runner);
}