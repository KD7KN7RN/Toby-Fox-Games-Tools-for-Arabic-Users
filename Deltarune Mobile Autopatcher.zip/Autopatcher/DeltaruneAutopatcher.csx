// Made by GFOXSH, 2026

using System;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;
using UndertaleModLib.Util;

bool firstTime = ScriptQuestion("Warning! Applying the patch multiple times may cause the game to malfunction. Are you sure this is the first time you've applied the patch?");

if (firstTime == false)
{
	return;
}

EnsureDataLoaded();

string dataPath = Path.Combine(Path.GetDirectoryName(ScriptPath), "obj_mobilecontrols");

Dictionary<string, UndertaleEmbeddedTexture> textures = new Dictionary<string, UndertaleEmbeddedTexture>();

UndertaleEmbeddedTexture controlsTexturePage = new UndertaleEmbeddedTexture();
controlsTexturePage.TextureData.Image = GMImage.FromPng(File.ReadAllBytes(Path.Combine(dataPath, "texture.png"))); // TODO: generate other formats
Data.EmbeddedTextures.Add(controlsTexturePage);
textures.Add(Path.GetFileName(Path.Combine(dataPath, "texture.png")), controlsTexturePage);

UndertaleTexturePageItem AddNewTexturePageItem(ushort sourceX, ushort sourceY, ushort sourceWidth, ushort sourceHeight)
{
    ushort targetX = 0;
    ushort targetY = 0;
    ushort targetWidth = sourceWidth;
    ushort targetHeight = sourceHeight;
    ushort boundingWidth = sourceWidth;
    ushort boundingHeight = sourceHeight;
    var texturePage = textures["texture.png"];

    UndertaleTexturePageItem tpItem = new() 
    { 
        SourceX = sourceX, 
        SourceY = sourceY, 
        SourceWidth = sourceWidth, 
        SourceHeight = sourceHeight, 
        TargetX = targetX, 
        TargetY = targetY, 
        TargetWidth = targetWidth, 
        TargetHeight = targetHeight, 
        BoundingWidth = boundingWidth, 
        BoundingHeight = boundingHeight, 
        TexturePage = texturePage,
        Name = new UndertaleString($"PageItem {Data.TexturePageItems.Count}")
    };
    Data.TexturePageItems.Add(tpItem);
    return tpItem;
}

UndertaleTexturePageItem pg_mobilecontrols_bg_0 = AddNewTexturePageItem(0, 0, 640, 480);
UndertaleTexturePageItem pg_mobilecontrols_jb_0 = AddNewTexturePageItem(642, 0, 59, 59);
UndertaleTexturePageItem pg_mobilecontrols_jb_1 = AddNewTexturePageItem(703, 0, 59, 59);
UndertaleTexturePageItem pg_mobilecontrols_js_0 = AddNewTexturePageItem(642, 61, 41, 41);
UndertaleTexturePageItem pg_mobilecontrols_js_1 = AddNewTexturePageItem(685, 61, 41, 41);
UndertaleTexturePageItem pg_mobilecontrols_z_0 = AddNewTexturePageItem(642, 104, 27, 29);
UndertaleTexturePageItem pg_mobilecontrols_z_1 = AddNewTexturePageItem(671, 104, 27, 29);
UndertaleTexturePageItem pg_mobilecontrols_x_0 = AddNewTexturePageItem(642, 135, 27, 29);
UndertaleTexturePageItem pg_mobilecontrols_x_1 = AddNewTexturePageItem(671, 135, 27, 29);
UndertaleTexturePageItem pg_mobilecontrols_c_0 = AddNewTexturePageItem(642, 166, 27, 29);
UndertaleTexturePageItem pg_mobilecontrols_c_1 = AddNewTexturePageItem(671, 166, 27, 29);
UndertaleTexturePageItem pg_mobilecontrols_f_0 = AddNewTexturePageItem(642, 197, 19, 23);
UndertaleTexturePageItem pg_mobilecontrols_f_1 = AddNewTexturePageItem(663, 197, 19, 23);
UndertaleTexturePageItem pg_mobilecontrols_s_0 = AddNewTexturePageItem(642, 222, 19, 23);
UndertaleTexturePageItem pg_mobilecontrols_s_1 = AddNewTexturePageItem(663, 222, 19, 23);
UndertaleTexturePageItem pg_mobilecontrols_sl_0 = AddNewTexturePageItem(642, 247, 28, 28);
UndertaleTexturePageItem pg_mobilecontrols_sl_1 = AddNewTexturePageItem(672, 247, 28, 28);

void AddNewUndertaleSprite(string spriteName, ushort width, ushort height, UndertaleTexturePageItem[] spriteTextures)
{
    var name = Data.Strings.MakeString(spriteName);
    ushort marginLeft = 0;
    int marginRight = width - 1;
    ushort marginTop = 0;
    int marginBottom = height - 1;

    var sItem = new UndertaleSprite { Name = name, Width = width, Height = height, MarginLeft = marginLeft, MarginRight = marginRight, MarginTop = marginTop, MarginBottom = marginBottom };
    foreach (var spriteTexture in spriteTextures) 
    {
        sItem.Textures.Add(new UndertaleSprite.TextureEntry() { Texture = spriteTexture });
    }
	
	if (spriteName != "spr_mobilecontrols_bg")
	{
		sItem.OriginXWrapper = (ushort)Math.Round(width / 2.0);
		sItem.OriginYWrapper = (ushort)Math.Round(height / 2.0);
	}
	
	Data.Sprites.Add(sItem);
}

AddNewUndertaleSprite("spr_mobilecontrols_bg", 640, 480, new UndertaleTexturePageItem[] {pg_mobilecontrols_bg_0});
AddNewUndertaleSprite("spr_mobilecontrols_jb", 59, 59, new UndertaleTexturePageItem[] {pg_mobilecontrols_jb_0, pg_mobilecontrols_jb_1});
AddNewUndertaleSprite("spr_mobilecontrols_js", 42, 42, new UndertaleTexturePageItem[] {pg_mobilecontrols_js_0, pg_mobilecontrols_js_1});
AddNewUndertaleSprite("spr_mobilecontrols_z", 27, 29, new UndertaleTexturePageItem[] {pg_mobilecontrols_z_0, pg_mobilecontrols_z_1});
AddNewUndertaleSprite("spr_mobilecontrols_x", 27, 29, new UndertaleTexturePageItem[] {pg_mobilecontrols_x_0, pg_mobilecontrols_x_1});
AddNewUndertaleSprite("spr_mobilecontrols_c", 27, 29, new UndertaleTexturePageItem[] {pg_mobilecontrols_c_0, pg_mobilecontrols_c_1});
AddNewUndertaleSprite("spr_mobilecontrols_f", 19, 23, new UndertaleTexturePageItem[] {pg_mobilecontrols_f_0, pg_mobilecontrols_f_1});
AddNewUndertaleSprite("spr_mobilecontrols_s", 19, 23, new UndertaleTexturePageItem[] {pg_mobilecontrols_s_0, pg_mobilecontrols_s_1});
AddNewUndertaleSprite("spr_mobilecontrols_sl", 28, 28, new UndertaleTexturePageItem[] {pg_mobilecontrols_sl_0, pg_mobilecontrols_sl_1});

UndertaleModLib.Compiler.CodeImportGroup importGroup = new(Data);

QueueGMLFile(Path.Combine(dataPath, "gml_Object_obj_mobilecontrols_Create_0.gml"));
QueueGMLFile(Path.Combine(dataPath, "gml_Object_obj_mobilecontrols_Draw_64.gml"));
QueueGMLFile(Path.Combine(dataPath, "gml_Object_obj_mobilecontrols_Other_3.gml"));
QueueGMLFile(Path.Combine(dataPath, "gml_Object_obj_mobilecontrols_Other_10.gml"));
QueueGMLFile(Path.Combine(dataPath, "gml_Object_obj_mobilecontrols_Step_1.gml"));

var mobileControls = Data.GameObjects.ByName("obj_mobilecontrols");
mobileControls.Persistent = true;

importGroup.Import();

void QueueGMLFile(string path)
{
    importGroup.QueueReplace(Path.GetFileNameWithoutExtension(path), File.ReadAllText(path));
}

ScriptMessage($"Integrated on-screen control.");

var newProductID = new byte[] { 0x55, 0x4E, 0x44, 0x45, 0x52, 0x54, 0x41, 0x4C, 0x45, 0x4E, 0x45, 0x57, 0x48, 0x4F, 0x50, 0x45 };
Data.FORM.EXTN.productIdData.Add(newProductID);

UndertaleExtension ext;
Data.Extensions.Add(ext = new UndertaleExtension()
{
	Name = Data.Strings.MakeString("GMSExtender"),
	ClassName = Data.Strings.MakeString("GMSExtender"),
	FolderName = Data.Strings.MakeString(".")
});

UndertaleExtensionFile file;
ext.Files.Add(file = new UndertaleExtensionFile()
{
	Filename = Data.Strings.MakeString("GMSExtender.ext"),
	Kind = UndertaleExtensionKind.Generic,
});

byte n = 0, d = 1, s = 2;
uint next_func_id = 1;

void AddFunc(string name, String extName, byte ret, params byte[] args)
{
	UndertaleExtensionFunction func;
	file.Functions.Add(func = new UndertaleExtensionFunction()
	{
		Name = Data.Strings.MakeString(name),
		ExtName = Data.Strings.MakeString(extName),
		ID = next_func_id++,
		Kind = 4,
		RetType = ret == s ? UndertaleExtensionVarType.String : UndertaleExtensionVarType.Double
    });

	foreach (byte arg in args)
	{
		func.Arguments.Add(new UndertaleExtensionFunctionArg(arg == s ? UndertaleExtensionVarType.String : UndertaleExtensionVarType.Double));
    }
	
    UndertaleFunction gameMakerFunc = new UndertaleFunction()
	{
        Name = Data.Strings.MakeString(name),
    };
    Data.Functions.Add(gameMakerFunc);
}

AddFunc("game_change_ext", "game_change_ext", d, s);

ScriptMessage($"Integrated Android support extension.");

string gameDir = Path.GetDirectoryName(FilePath);
List<string> soundFilesToDelete = new List<string>();
List<UndertaleSound> externalSounds = new List<UndertaleSound>();

foreach (var sound in Data.Sounds)
{
    if (sound.AudioFile == null && sound.AudioID == -1)
    {
        string fileName = sound.File?.Content;
        if (!string.IsNullOrEmpty(fileName))
        {
            string fullPath = Path.Combine(gameDir, fileName);
            if (File.Exists(fullPath))
            {
                externalSounds.Add(sound);
                soundFilesToDelete.Add(fullPath);
            }
        }
    }
}

if (externalSounds.Count > 0)
{
    for (int i = 0; i < externalSounds.Count; i++)
    {
        var sound = externalSounds[i];
        string filePath = soundFilesToDelete[i];

        try
        {
            byte[] fileBytes = File.ReadAllBytes(filePath);
            UndertaleEmbeddedAudio embeddedAudio = new() { Data = fileBytes };
            Data.EmbeddedAudio.Add(embeddedAudio);

            bool isOGG = Path.GetExtension(filePath).Equals(".ogg", StringComparison.OrdinalIgnoreCase);
            UndertaleSound.AudioEntryFlags flags;
            if (isOGG)
            {
                flags = UndertaleSound.AudioEntryFlags.IsCompressed | UndertaleSound.AudioEntryFlags.Regular;
            }
            else
            {
                flags = UndertaleSound.AudioEntryFlags.IsEmbedded | UndertaleSound.AudioEntryFlags.Regular;
            }

            sound.Flags = flags;
            sound.AudioFile = embeddedAudio;
            sound.AudioID = -1;
            sound.GroupID = Data.GetBuiltinSoundGroupID();
            sound.AudioGroup = (Data.AudioGroups.Count > 0) ? Data.AudioGroups[Data.GetBuiltinSoundGroupID()] : null;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Audio Integration Error] Failed to integrate '{sound.Name?.Content}': {ex.Message}");
        }
    }

    foreach (var filePath in soundFilesToDelete)
    {
        try
        {
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Audio Integration Error] Failed to delete file '{filePath}': {ex.Message}");
        }
    }
}

int roomCount = 0;

foreach (var room in Data.Rooms)
{
    if (room == null) continue;
    
    if (room.Flags.HasFlag(UndertaleRoom.RoomEntryFlags.DoNotClearDisplayBuffer))
    {
        room.Flags &= ~UndertaleRoom.RoomEntryFlags.DoNotClearDisplayBuffer;
        roomCount++;
    }
}

ScriptMessage($"Ghosting fix applied to {roomCount} rooms.");

string displayName = Data.GeneralInfo?.DisplayName?.Content.ToLower();

string chapter = "ch0";

if (displayName == "deltarune chapter 1")
{
	chapter = "ch1";
}

if (displayName == "deltarune chapter 2")
{
	chapter = "ch2";
}

if (displayName == "deltarune chapter 3")
{
	chapter = "ch3";
}

if (displayName == "deltarune chapter 4")
{
	chapter = "ch4";
}

if (displayName == "deltarune chapter 5")
{
	chapter = "ch5";
}

string path = Path.Combine(Path.GetDirectoryName(ScriptPath), chapter);

if (Directory.Exists(path))
{
	string[] flies = Directory.GetFiles(path, "*.gml");
	
	if (flies.Length > 0)
	{
		UndertaleModLib.Compiler.CodeImportGroup importGroupLocal = new(Data)
		{
			AutoCreateAssets = true
		};
		
		foreach (string file in flies)
		{
			string code = File.ReadAllText(file);
			string codeName = Path.GetFileNameWithoutExtension(file);
			importGroupLocal.QueueReplace(codeName, code);
		}
		
		importGroupLocal.Import();
		
		ScriptMessage($"Imported {flies.Length} fix files from folder {chapter}.");
	}
	else
	{
		ScriptMessage($"No GML files found in folder {chapter}.");
	}
}
else
{
	ScriptMessage($"Folder {chapter} not found.");
}

ScriptMessage($"Patching is complete. Build your APK.");