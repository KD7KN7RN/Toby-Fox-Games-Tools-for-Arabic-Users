if (settings_alpha > 0)
{
    draw_sprite_ext(spr_mobilecontrols_bg, 0, 0, 0, 1, 1, 0, c_white, settings_alpha);
    draw_sprite_ext(spr_mobilecontrols_sl, (settings_slider == 0) ? 1 : 0, lerp(54, 268, (touchscreen_deadzone - 0) / 1), 131, 1, 1, 0, c_white, settings_alpha);
    draw_sprite_ext(spr_mobilecontrols_sl, (settings_slider == 1) ? 1 : 0, lerp(54, 268, (touchscreen_scale[0] - 2) / 2), 195, 1, 1, 0, c_white, settings_alpha);
    draw_sprite_ext(spr_mobilecontrols_sl, (settings_slider == 2) ? 1 : 0, lerp(54, 268, (touchscreen_scale[1] - 2) / 2), 259, 1, 1, 0, c_white, settings_alpha);
    draw_sprite_ext(spr_mobilecontrols_sl, (settings_slider == 3) ? 1 : 0, lerp(54, 268, (touchscreen_type - 0) / 3), 323, 1, 1, 0, c_white, settings_alpha);
    draw_sprite_ext(spr_mobilecontrols_sl, (settings_slider == 4) ? 1 : 0, lerp(54, 268, (touchscreen_opacity - 0.2) / 0.8), 387, 1, 1, 0, c_white, settings_alpha);
}

var _touchscreen_type = 0;

switch (touchscreen_type)
{
    case 0:
    case 2:
        _touchscreen_type = 0;
        break;
    
    case 1:
    case 3:
        _touchscreen_type = 1;
        break;
}

draw_sprite_ext(spr_mobilecontrols_jb, _touchscreen_type, joybase_x[0], joybase_y[0], touchscreen_scale[0], touchscreen_scale[0], image_angle, image_blend, image_alpha * clamp(joystick_alpha[0], 0, 1));
draw_sprite_ext(spr_mobilecontrols_js, _touchscreen_type, joystick_x[0], joystick_y[0], touchscreen_scale[0], touchscreen_scale[0], image_angle, image_blend, image_alpha * clamp(joystick_alpha[0], 0, 1));
draw_sprite_ext(spr_mobilecontrols_f, key_state[7], touchscreen_x[3], touchscreen_y[3], touchscreen_scale[1], touchscreen_scale[1], image_angle, image_blend, image_alpha * f_alpha);
draw_sprite_ext(spr_mobilecontrols_c, key_state[6], touchscreen_x[2], touchscreen_y[2], touchscreen_scale[1], touchscreen_scale[1], image_angle, image_blend, image_alpha);
draw_sprite_ext(spr_mobilecontrols_x, key_state[5], touchscreen_x[1], touchscreen_y[1], touchscreen_scale[1], touchscreen_scale[1], image_angle, image_blend, image_alpha);
draw_sprite_ext(spr_mobilecontrols_z, key_state[4], touchscreen_x[0], touchscreen_y[0], touchscreen_scale[1], touchscreen_scale[1], image_angle, image_blend, image_alpha);
draw_sprite_ext(spr_mobilecontrols_s, settings_z, settings_x, settings_y, touchscreen_scale[1], touchscreen_scale[1], image_angle, image_blend, touchscreen_opacity);
